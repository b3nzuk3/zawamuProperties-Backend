import fs from 'node:fs/promises'
import https from 'node:https'
import path from 'node:path'
import { once } from 'node:events'
import { createRequire } from 'node:module'
const backend = '/home/b3nzuk3/Projects/client-projects/zawamu/zawamuProperties-Backend'
const frontend = '/home/b3nzuk3/Projects/client-projects/zawamu/zawamuProperties-frontEnd'
const require = createRequire(`${backend}/package.json`)
const express = require('express'), jwt = require('jsonwebtoken'), sharp = require('sharp')
const {createImageStorage} = await import(`${backend}/src/services/imageStorage.js`)
const {createUploadRouter} = await import(`${backend}/src/routes/upload.js`)
const {default: User} = await import(`${backend}/src/models/User.js`)
process.env.ADMIN_EMAILS = 'owner@example.test'
process.env.JWT_SECRET = 'disposable-heic-browser-fixture'
User.findById = async () => ({_id:'actor',email:'owner@example.test'})
const objects = new Map(), events = [], uploads = []
const app = express()
const server = https.createServer({key:await fs.readFile('fixture-key.pem'),cert:await fs.readFile('fixture-cert.pem')},app)
server.listen(0,'127.0.0.1'); await once(server,'listening')
const origin = `https://127.0.0.1:${server.address().port}`
const env = {R2_ACCOUNT_ID:'a'.repeat(32),R2_ACCESS_KEY_ID:'fixture',R2_SECRET_ACCESS_KEY:'fixture',R2_BUCKET_NAME:'fixture-images',R2_PUBLIC_URL:`${origin}/media`}
const client = {async send(command){const {Key,Body}=command.input; if(command.constructor.name==='PutObjectCommand')objects.set(Key,Body);else objects.delete(Key);return {}}}
const storage = createImageStorage({env,client})
const initial = await storage.uploadImages([{buffer:await sharp({create:{width:100,height:50,channels:3,background:'red'}}).png().toBuffer()}])
let property = {_id:'64b000000000000000000001',title:'HEIC fixture home',description:'Disposable image acceptance fixture.',location:'Nairobi',type:'Apartment',listingPurpose:'sale',availability:'available',price:5000000,offerPercent:0,bedrooms:2,bathrooms:2,area:800,features:[],images:initial.urls}
app.use((req,res,next)=>{const pathname=req.path;res.on('finish',()=>events.push({method:req.method,path:pathname,status:res.statusCode}));next()})
app.get('/media/*',(req,res)=>{const b=objects.get(req.path.slice(1));return b?res.type('webp').send(b):res.sendStatus(404)})
app.get('/fixture/bootstrap',(_req,res)=>res.json({token:jwt.sign({userId:'actor'},process.env.JWT_SECRET)}))
app.get('/fixture/events',(_req,res)=>res.json({events,uploads,images:property.images,objectCount:objects.size}))
app.use('/api/upload',createUploadRouter({storeImages:async files=>{const start=performance.now();const result=await storage.uploadImages(files);uploads.push({bytes:files.map(f=>f.buffer.length),elapsedMs:Math.round(performance.now()-start),urls:result.urls});return result}}))
app.use(express.json())
app.get('/api/auth/profile',(_req,res)=>res.json({id:'actor',name:'Fixture Owner',email:'owner@example.test',isAdmin:true}))
app.get('/api/properties',(_req,res)=>res.json([property]))
app.get('/api/properties/:id',(_req,res)=>res.json(property))
app.put('/api/properties/:id',(req,res)=>{property={...property,...req.body};res.json(property)})
app.post('/api/properties',(req,res)=>res.status(201).json({_id:'64b000000000000000000004',...req.body}))
app.get('/api/features',(_req,res)=>res.json([]))
app.get('/api/admin/stats',(_req,res)=>res.json({totals:{properties:1,activeListings:1,blogPosts:0,inquiries:0},monthOverMonth:{properties:0,activeListings:0,blogPosts:0,inquiries:0}}))
app.get('/api/admin/recent-activity',(_req,res)=>res.json([]))
app.get('/api/blog',(_req,res)=>res.json([]))
app.post('/api/blog',(req,res)=>res.status(201).json({_id:'fixture-post',...req.body}))
app.use('/api',(_req,res)=>res.status(404).json({message:'Unknown fixture API'}))
app.use(express.static(`${frontend}/dist`));app.get('*',(_req,res)=>res.sendFile(`${frontend}/dist/index.html`))
await fs.writeFile('runtime.json',JSON.stringify({origin,mediaBase:env.R2_PUBLIC_URL}))
console.log('Owned HEIC fixture ready')
let stopping=false
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,async()=>{if(stopping)return;stopping=true;objects.clear();await new Promise(resolve=>{server.close(resolve);server.closeAllConnections()});await fs.writeFile('cleanup.json',JSON.stringify({objects:objects.size,serverClosed:!server.listening}));process.exit(0)})
