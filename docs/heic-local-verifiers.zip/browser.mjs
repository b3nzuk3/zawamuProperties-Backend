import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
import { chromium } from '/home/b3nzuk3/.hermes/profiles/orcha/cache/scratch/zawamu-r2-verify-q5tvlh0a/node_modules/playwright/index.mjs'
const {origin}=JSON.parse(await fs.readFile('runtime.json','utf8'))
const file='/home/b3nzuk3/.hermes/profiles/orcha/attachments/nB8cLL1d.heif.part'
const bytes=await fs.readFile(file)
const selected={name:'client-photo.heif',mimeType:'image/heif',buffer:bytes}
const browser=await chromium.launch({executablePath:'/usr/sbin/chromium',headless:true,args:['--no-sandbox']})
const context=await browser.newContext({ignoreHTTPSErrors:true})
const page=await context.newPage(), checks=[],errors=[],responses=[]
let phase='setup'
page.on('pageerror',e=>errors.push({phase,message:e.message}))
page.on('console',m=>{if(m.type()==='error')errors.push({phase,message:m.text()})})
page.on('response',r=>{if(r.url().startsWith(origin))responses.push({phase,path:new URL(r.url()).pathname,status:r.status()})})
await context.route('**/*',route=>{
  if(route.request().url().startsWith(origin+'/'))return route.continue()
  if(route.request().resourceType()==='stylesheet')return route.fulfill({contentType:'text/css',body:''})
  if(route.request().url().includes('exchangerate-api.com'))return route.fulfill({json:{rates:{USD:1,KES:130},base:'USD'}})
  return route.abort()
})
async function uploadAndSave(button){
  const wait=page.waitForResponse(r=>r.url().endsWith('/api/upload')&&r.request().method()==='POST')
  await button.click();const response=await wait;assert.equal(response.status(),200)
  const result=await response.json();assert.ok(result.urls[0].endsWith('/large.webp'))
  checks.push({phase,name:'real multipart HEVC conversion',status:response.status()})
}
try{
  await page.goto(origin,{waitUntil:'networkidle'})
  await page.evaluate(async()=>{const r=await fetch('/fixture/bootstrap').then(r=>r.json());localStorage.setItem('token',r.token)})
  for(const width of [390,1440]){
    phase=`edit-${width}`;await page.setViewportSize({width,height:950})
    await page.goto(origin+'/admin/properties',{waitUntil:'networkidle'})
    await page.getByRole('button',{name:'Edit',exact:true}).click()
    const input=page.locator('#edit-property-images')
    assert.ok((await input.getAttribute('accept')).includes('.heif'))
    await input.setInputFiles(selected)
    const placeholder=page.getByRole('img',{name:'Selected file: client-photo.heif',exact:true})
    await placeholder.scrollIntoViewIfNeeded();await placeholder.waitFor()
    assert.equal(await page.locator('img[alt="Preview"]').count(),0)
    const geometry=await placeholder.boundingBox();assert.ok(geometry.x>=0&&geometry.x+geometry.width<=width)
    await page.screenshot({path:`heic-selected-${width}.png`})
    checks.push({phase,name:'HEIF filename placeholder and geometry',width})
    await uploadAndSave(page.getByRole('button',{name:'Save Changes',exact:true}))
    await page.getByRole('heading',{name:'Edit Property',exact:true}).waitFor({state:'hidden'})
    await page.reload({waitUntil:'networkidle'})
    await page.getByRole('button',{name:'Edit',exact:true}).click()
    const images=page.locator('img[alt^="Property "]')
    const last=images.last();await last.evaluate(i=>i.decode())
    const decoded=await last.evaluate(i=>({width:i.naturalWidth,height:i.naturalHeight,src:i.src}))
    assert.ok(decoded.src.endsWith('/thumbnail.webp'));assert.deepEqual([decoded.width,decoded.height],[240,320])
    checks.push({phase,name:'saved canonical WebP survives fixture reload; thumbnail decodes',...decoded,src:undefined})
  }
  phase='create';await page.goto(origin+'/admin',{waitUntil:'networkidle'})
  await page.getByRole('button',{name:'Add Property',exact:true}).click()
  await page.getByLabel('Title',{exact:true}).fill('HEIC acceptance home')
  await page.getByLabel('Description',{exact:true}).fill('Disposable fixture only')
  await page.getByLabel('Location',{exact:true}).fill('Nairobi')
  await page.getByLabel('Sale price (KES)',{exact:true}).fill('5000000')
  await page.locator('#add-property-images').setInputFiles(selected)
  await page.getByRole('img',{name:'Selected file: client-photo.heif',exact:true}).waitFor()
  await uploadAndSave(page.getByRole('button',{name:'Add Property',exact:true}).last())
  await page.getByRole('heading',{name:'Add Property',exact:true}).waitFor({state:'hidden'})
  phase='blog';await page.getByRole('button',{name:'New Post',exact:true}).click()
  await page.getByLabel('Title',{exact:true}).fill('HEIC fixture article')
  await page.locator('#post-image').setInputFiles(selected)
  await page.getByRole('img',{name:'Selected file: client-photo.heif',exact:true}).waitFor()
  await uploadAndSave(page.getByRole('button',{name:'Add Post',exact:true}))
  await page.locator('#post-image').waitFor({state:'hidden'})
  const state=await page.evaluate(()=>fetch('/fixture/events').then(r=>r.json()))
  assert.equal(state.uploads.length,4);assert.ok(state.uploads.every(u=>u.bytes.length===1&&u.bytes[0]===bytes.length))
  assert.ok(state.images.every(url=>url.endsWith('/large.webp')))
  assert.equal(responses.some(r=>r.status>=400),false);assert.deepEqual(errors,[])
  await fs.writeFile('browser-result.json',JSON.stringify({passed:true,checks,responses,errors,uploads:state.uploads.map(({bytes,elapsedMs})=>({bytes,elapsedMs})),fixtureLimits:['Real Chromium production React, multipart owner middleware, HEVC WASM and Sharp; in-memory owner/profile/catalogue/property/blog and S3 method doubles, not Mongo/R2 acceptance','Fonts and currency intercepted; no outbound provider/message/database calls'],clientImageVersioned:false},null,2))
  console.log(JSON.stringify({passed:true,checks:checks.length,responses:responses.length,uploads:state.uploads.length,errors:errors.length}))
}catch(e){await fs.writeFile('browser-failure.json',JSON.stringify({phase,error:e.message,checks,responses,errors},null,2));await page.screenshot({path:'browser-failure.png'});throw e}
finally{await context.close();await browser.close()}
